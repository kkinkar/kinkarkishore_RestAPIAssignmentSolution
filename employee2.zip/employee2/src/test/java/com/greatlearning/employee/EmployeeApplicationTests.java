package com.greatlearning.employee;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
